alias terraform=tf
git config --global user.name "Harshit Aranya"
git config --global user.email harshit.aranya@gmail.com
git remote add origin https://github.com/HarshitAranya/devops.git
