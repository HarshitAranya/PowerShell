select @@SERVERNAME as hostname
