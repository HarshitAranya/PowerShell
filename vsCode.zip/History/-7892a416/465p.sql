Use[master]
select @@SERVERNAME as hostname
select * from msdb..sysjobs
