Use[master]
select @@SERVERNAME as hostname
select * from msdb..sysjobs
use[view]
sp_helptext 'Notices_InsertChallenge'
