Use[master]
select @@SERVERNAME as hostname
select * from msdb..sysjobs
use[view]
sp_helptext 'Notices_InsertChallenge'
select * from sys.databases
sp_detach_db 'DBNAME', 'true';
