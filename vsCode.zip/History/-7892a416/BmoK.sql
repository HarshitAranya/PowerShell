use[VIEW];
 --DECLARE @date AS VARCHAR(100)='2023-05-29'; 5
 DECLARE @date AS VARCHAR(100) = (SELECT CONVERT (Date, GETDATE()) AS [Current Date])
 Select Top (60)(Failed + Completed) as Total, * From DJR_Monitoring_BulkProcessor where Type = 'Notice1bImportMessage' AND CAST(Created AS DATE) = @date Order By Created DESC;
 Select Top (60) SUM((Failed + Completed)) as Total_Notice From DJR_Monitoring_BulkProcessor where Type = 'Notice1bImportMessage' AND CAST(Created AS DATE) = @date;

 --Take batch ID if count not matched
 Select Status, Errors AS Failed_Notices from Queue_ImportQueue where BatchId IN 
 ( Select Top (60) BatchId From DJR_Monitoring_BulkProcessor where Type = 'Notice1bImportMessage' AND CAST(Created AS DATE) = @date and Failed != 0 Order By Created DESC)
 and status != 5

 Select Top (60)(Failed + Completed) as Total, * From DJR_Monitoring_BulkProcessor where Type = 'ImportImageFileMessage' AND CAST(Created AS DATE) = @date Order By Created DESC;
 Select Top (60) SUM((Failed + Completed)) as Total_Notice_Processed From DJR_Monitoring_BulkProcessor where Type = 'ImportImageFileMessage' AND CAST(Created AS DATE) = @date;

 Select * from Queue_ImportQueue where BatchId IN 
 ( Select Top (60) BatchId From DJR_Monitoring_BulkProcessor where Type = 'ImportImageFileMessage' AND CAST(Created AS DATE) = @date and Failed != 0 Order By Created DESC)
 and status != 5