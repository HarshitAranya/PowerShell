//print "hello world"


/*
comment
println Byte.MIN_VALUE
println Byte.MAX_VALUE

def h = "Haяshit मैं"
println h
assert 1 + 2 == 3

def result = (1 == 1) ? '1st' : '2nd'
println result

def nm = 200
if (nm == 2) {
    print nm   
}
else if ( nm == 20) {
    println nm
}
else { print "error"}

def nm = 10
switch(nm) {
    case {nm>12}:
        result = "is 10"
    break
    case {nm==1}:
        result = "is 1"
    break
    case {nm!=1}:
        result = "end"
    break    
}
println result

for(i = 0; i<5; i++){
    println "my code"
}

for(i in 0..5){
    println "my code"
}

2.upto(4){
    println "this - " + "$it"
}

3.times {println "$it"}

2.step(20, 5) {println "ok"}

try{ int i = 1/0 }
catch(Exception exp) { println "Error ${exp}"
    println exp.getMessage()
    println exp.getCause()
 }


try{ int i = 1/0 }
catch(ArithmeticException AEexp){ println "this is arithmetic exception"}
catch(Exception exp) { println "Error ${exp}"
    println exp.getMessage()
    println exp.getCause()
 }
finally{ println "this will run finally"}
 println "next"


try{ int i = 1/1 }
catch(ArithmeticException AEexp){ println "this is arithmetic exception"}
catch(Exception exp) { println "Error ${exp}"
    println exp.getMessage()
    println exp.getCause()
 }
finally{ println "this will run finally"}
 println "next"

 try{ int i = 1/1 }
finally{ println "this will run finally"}
println "next"


println 'single quoted'
println "double quoted"
println '''tripal single'''
println """tripal double"""
//println /slashy/
println $/dollar slashy/$

def env = "Tst4"
def env1 = "tst4"

if(env == env1){
    println "True"
}else {
    println "False"
}

*/


import groovy.json.JsonSlurper

def str = 'C:\Harshit\eLearning\Groovy\upl.txt' //(new URL('http://envs.dfghod.local/Drops_Builds_json.txt?p=1')).text 

def parser = new JsonSlurper()
def json = parser.parseText(str)

json.keySet() as List





















