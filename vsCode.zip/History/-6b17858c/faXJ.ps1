

Try {
    $a = 1 + 'a'
    Write-Host $a
 }  Catch  {
    Write-Host "Something went wrong"
 } 