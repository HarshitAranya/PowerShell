
Try {
    $a = 1 + 'a'
    Write-Host $a
  } Catch [System.IO.IOException] {
    Write-Host "Something IO went wrong: $($_.exception.message)"
  }  Catch {
    Write-Host "Something else went wrong: $($_.exception.message)"
  }