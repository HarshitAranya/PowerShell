$PI = 3.14

Write-Host "An expression $($PI + 1)"