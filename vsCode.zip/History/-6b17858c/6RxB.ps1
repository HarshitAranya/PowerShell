

Try {
    $a = 1 + 'a'
    Write-Host $a
 }  Catch [System.IO.IOException] {
    Write-Host "Something went wrong"
 } 