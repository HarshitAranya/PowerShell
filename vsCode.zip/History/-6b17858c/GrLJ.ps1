$a = 1 + 'a'

Try {
    $a
 }  Catch {
    "Unable"
 }