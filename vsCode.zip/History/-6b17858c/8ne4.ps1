$a = 1 + 'a'

Try {
    $a
 } Catch [System.IO.IOException] {
    Write-Host "Something went wrong"
 }  Catch {
    "Unable"
 }