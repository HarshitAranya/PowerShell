Param(
    $Name
)

Write-Host "Your name is $Name"