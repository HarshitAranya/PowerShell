import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-directive',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './directive.component.html',
  styleUrl: './directive.component.css'
})
export class DirectiveComponent {

  isDiv1Visiable: boolean = false;

  showDiv(){
    this.isDiv1Visiable = true;
  }
  hideDiv(){
    this.isDiv1Visiable = false;
  }

  toggleDiv(){
    this.isDiv1Visiable = !this.isDiv1Visiable;
  }
}
