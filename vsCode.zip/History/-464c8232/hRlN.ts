import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-directive',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './directive.component.html',
  styleUrl: './directive.component.css'
})
export class DirectiveComponent {

  isDiv1Visiable: boolean = false;
  isDiv2Visiable: boolean = false;

  num1: string = '';
  num2: string = '';

  showDiv(){
    this.isDiv1Visiable = true;
  }
  hideDiv(){
    this.isDiv1Visiable = false;
  }

  toggleDiv(){
    this.isDiv2Visiable = !this.isDiv2Visiable;
  }
}
