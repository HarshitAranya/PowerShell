import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-directive',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './directive.component.html',
  styleUrl: './directive.component.css'
})
export class DirectiveComponent {

  isDiv1Visiable: boolean = false;
  isDiv2Visiable: boolean = false;
  // isActive: boolean = false;
  isIND: string = "";

  num1: string = '';
  num2: string = '';

  cityArray: string [] = ['Indore', 'Dewas', 'Dhar', 'Guna'];
  sudentList: any[] = [
    { name:'AAA', city: 'Pune', isActive: false },
    { name:'BBB', city: 'INDORE', isActive: false },
    { name:'CCC', city: 'Dewas', isActive: true },
    { name:'DDD', city: 'MHOW', isActive: false },
    { name:'EEE', city: 'ROW', isActive: false },
    { name:'FFF', city: 'GUNA', isActive: false },
  ]

  showDiv(){
    this.isDiv1Visiable = true;
  }
  hideDiv(){
    this.isDiv1Visiable = false;
  }

  toggleDiv(){
    this.isDiv2Visiable = !this.isDiv2Visiable;
  }

  // isChecked(){
  //   this.isActive = !this.isActive
  // }
}
