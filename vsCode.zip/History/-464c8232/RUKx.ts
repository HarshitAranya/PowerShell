import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-directive',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './directive.component.html',
  styleUrl: './directive.component.css'
})
export class DirectiveComponent {

  isDiv1Visiable: boolean = false;
  isDiv2Visiable: boolean = false;
  // isActive: boolean = false;
  isIND: string = "";

  num1: string = '';
  num2: string = '';

  cityArray: string [] = ['Indore', 'Dewas', 'Dhar', 'Guna'];
  sudentList: any[] = [
    { sudentId: 11, name:'AAA', city: 'Pune', isActive: false },
    { sudentId: 22, name:'BBB', city: 'INDORE', isActive: false },
    { sudentId: 33, name:'CCC', city: 'Dewas', isActive: true },
    { sudentId: 44, name:'DDD', city: 'MHOW', isActive: false },
    { sudentId: 55, name:'EEE', city: 'ROW', isActive: false },
    { sudentId: 66, name:'FFF', city: 'GUNA', isActive: false },
  ]

  showDiv(){
    this.isDiv1Visiable = true;
  }
  hideDiv(){
    this.isDiv1Visiable = false;
  }

  toggleDiv(){
    this.isDiv2Visiable = !this.isDiv2Visiable;
  }

  // isChecked(){
  //   this.isActive = !this.isActive
  // }
}
