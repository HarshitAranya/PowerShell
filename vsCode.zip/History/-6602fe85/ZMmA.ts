import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { CreateComponent } from './create/create.component';
import { ReadComponent } from './read/read.component';
// import { appRoutes } from './app.routes';

// @NgModule({
//   declarations: [
//     AppComponent,
//     CreateComponent,
//     ReadComponent
//   ],
//   imports: [
//     BrowserModule,
//     RouterModule.forRoot(appRoutes)
//   ],
//   providers: [],
//   bootstrap: [AppComponent]
// })
// export class AppModule { }

@NgModule({
    imports: [RouterModule.forRoot(App.routes)],
    exports: [RouterModule]
})
export class AppModule { }