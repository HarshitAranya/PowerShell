import { Component, inject } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [RouterOutlet, RouterLink],
  templateUrl: './layout.component.html',
  styleUrl: './layout.component.css'
})
export class LayoutComponent {

  router = inject(Router);

  logOut(){
    localStorage.removeItem('loginUser');
    this.router.navigateByUrl('login')
  }

  loggedUserData: any;

  constructor(){
    const loggedData = localStorage.getItem('loginUser');
    if(loggedData != null){
      this.loggedUserData = JSON.parse(loggedData);
      // alert(this.loggedUserData.emailId)
    }
  }

}
