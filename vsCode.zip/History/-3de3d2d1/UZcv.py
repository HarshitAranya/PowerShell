# pip install --no-index --find-links . botocore

import pandas as pd

# Load the CSV into a DataFrame
csv_file = "sql.csv"
df = pd.read_csv(csv_file)

# Get unique table names
unique_tables = df["TableName"].unique()

for table_name in unique_tables:
    # Get all SQL statements for the current table
    sql_statements = df[df["TableName"] == table_name]["SQLStatement"]
    
    # Concatenate all SQL statements with a newline
    all_sql = "\n".join(sql_statements)
    
    # Format the SQL by replacing "CREATE " with "\nCREATE "
    formatted_sql = all_sql.replace("CREATE ", "\nCREATE ")
    
    # Print the formatted SQL (you can write it to a file if needed)
    #print(f"Formatted SQL for {table_name}:\n{formatted_sql}\n")
    print(table_name)
    print("\n{formatted_sql}\n")
    
    # Uncomment the following lines to save each formatted SQL to a separate file
    # output_file = f"{table_name}.sql"
    # with open(output_file, "w") as file:
    #     file.write(formatted_sql)
