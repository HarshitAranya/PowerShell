// import { NgModule } from '@angular/core';
// import { BrowserModule } from '@angular/platform-browser';
// import { RouterModule } from '@angular/router';
// import { AppComponent } from './app.component';
// import { CreateComponent } from './create/create.component';
// import { ReadComponent } from './read/read.component';
// import { appRoutes } from './app.routes';

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
// import { appRoutes } from './app.routes';
import { AppComponent } from './app.component';
import { CreateComponent } from './create/create.component';
import { ReadComponent } from './read/read.component';

const appRoutes:Routes=[
  {path: 'create', component: CreateComponent},
  {path: 'read', component: ReadComponent}
]

@NgModule({
  declarations: [
    // Remove AppComponent, CreateComponent, and ReadComponent from declarations
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes)
  ],
  // bootstrap: [AppComponent],  // Bootstrap only AppComponent
  providers: []
})
export class AppModule { }