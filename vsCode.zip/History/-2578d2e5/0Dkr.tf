module "provider" {
  source = "../module/provider"
}