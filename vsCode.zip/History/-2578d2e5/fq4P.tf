# configure AWS provider
provider "aws" {
    region = "us-west-2"
    profile = "local aws cli profile name"  
}

module "vpc" {
  source = "..modules/vpc/"
  
}
