# configure AWS provider
provider "aws" {
    region = var.region
    profile = "local aws cli profile name"  
}

module "vpc" {
  source = "..modules/vpc/"
  
}

#SSH from putty by using ppk | ssh-keygen -t rsa
resource "aws_key_pair" "KeyToConnect" {
  key_name = "KeyToConnect" #name should be there in txt file
  public_key = file("${var.pubkeypath}") #var.pubkeypath #file("pubkeyforsshputty.txt") not defigned in variable. it will be pars at the time of execution
}


# data "template_file" "private_key" {
#   template = file("id_rsa.txt")
# }

#extra key to ssh in place of pem key
data "template_file" "private_sshkey" {
  template = file("id_rsa")
}

# Extra code for line 299 331
# data "template_file" "public_key" {
#   template = file("id_rsa.pub.txt")
# }

#VPC
resource "aws_vpc" "VPCIP8000N8" {
  cidr_block       = var.vpc_cidr
  instance_tenancy = "default"
  enable_dns_hostnames = true

  tags = {
    Name = "VPCIP8000N8"
  }
}
output "aws-vpc-name" {
  value       = aws_vpc.VPCIP8000N8.id
  description = "This can be use in ansible script or other tools" # use terraform output or terraform output aws-vpc-name to see the value 
}


#Subnet Creation

#1.First Subnet
resource "aws_subnet" "SUB-1-VPCIP8000N8" {
  vpc_id            = aws_vpc.VPCIP8000N8.id
  availability_zone = "us-west-2a"
  cidr_block        = var.SUB_cidr_block[0]
  map_public_ip_on_launch = true

  tags = {
    Name = var.SUB_Tag_Name[0]
  }
}

#2. Second Subnet
resource "aws_subnet" "SUB-2-VPCIP8000N8" {
  vpc_id            = aws_vpc.VPCIP8000N8.id
  availability_zone = "us-west-2b"
  cidr_block        = var.SUB_cidr_block[1]
  map_public_ip_on_launch = true

  tags = {
    Name = var.SUB_Tag_Name[1]
  }
}

#3. Third Subnet
resource "aws_subnet" "SUB-3-VPCIP8000N8" {
  //vpc_id            = "vpc-0d627de12f26a2650"
  vpc_id            = aws_vpc.VPCIP8000N8.id
  availability_zone = "us-west-2c"
  //cidr_block        = "172.16.64.0/19"
  cidr_block        = var.SUB_cidr_block[2]
  map_public_ip_on_launch = true

  tags = {
    Name = "SUB-3-VPCIP8000N8"
  }
}

#4. Fourth Subnet
resource "aws_subnet" "SUB-4-VPCIP8000N8" {
  //vpc_id            = "vpc-0d627de12f26a2650"
  vpc_id            = aws_vpc.VPCIP8000N8.id
  availability_zone = "us-west-2d"
  //cidr_block        = "172.16.96.0/19"
  cidr_block        = var.SUB_cidr_block[3]
  map_public_ip_on_launch = true

  tags = {
    Name = "SUB-4-VPCIP8000N8"
  }
}

output "aws_subnet-name1" {
  value       = aws_subnet.SUB-1-VPCIP8000N8.id
  description = "This can be use in ansible script or other tools" # use terraform output or terraform output aws-vpc-name to see the value 
}
output "aws_subnet-name2" {
  value       = aws_subnet.SUB-2-VPCIP8000N8.id
  description = "This can be use in ansible script or other tools" # use terraform output or terraform output aws-vpc-name to see the value 
}
output "aws_subnet-name3" {
  value       = aws_subnet.SUB-3-VPCIP8000N8.id
  description = "This can be use in ansible script or other tools" # use terraform output or terraform output aws-vpc-name to see the value 
}
output "aws_subnet-name4" {
  value       = aws_subnet.SUB-4-VPCIP8000N8.id
  description = "This can be use in ansible script or other tools" # use terraform output or terraform output aws-vpc-name to see the value 
}

#$ terraform import aws_internet_gateway.gw igw-c0a643a9
resource "aws_internet_gateway" "IG_VPCIP8000N8" {
  //vpc_id = "vpc-0d627de12f26a2650"
  vpc_id            = aws_vpc.VPCIP8000N8.id

  tags = {
    Name = "IG_VPCIP8000N8"
  }
}

resource "aws_route_table" "Route-VPCIP8000N8" {
  vpc_id = "${aws_vpc.VPCIP8000N8.id}"

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = "${aws_internet_gateway.IG_VPCIP8000N8.id}"
  }
  
  tags = {
    Name = "Route-VPCIP8000N8"
  }
}

resource "aws_main_route_table_association" "Route-VPCIP8000N8" {
    vpc_id         = "${aws_vpc.VPCIP8000N8.id}"
    route_table_id = "${aws_route_table.Route-VPCIP8000N8.id}"
}

#subnet associations
resource "aws_route_table_association" "SUB-1-VPCIP8000N8" {
  subnet_id      = aws_subnet.SUB-1-VPCIP8000N8.id
  route_table_id = aws_route_table.Route-VPCIP8000N8.id
}
resource "aws_route_table_association" "SUB-2-VPCIP8000N8" {
  subnet_id      = aws_subnet.SUB-2-VPCIP8000N8.id
  route_table_id = aws_route_table.Route-VPCIP8000N8.id
}
resource "aws_route_table_association" "SUB-3-VPCIP8000N8" {
  subnet_id      = aws_subnet.SUB-3-VPCIP8000N8.id
  route_table_id = aws_route_table.Route-VPCIP8000N8.id
}
resource "aws_route_table_association" "SUB-4-VPCIP8000N8" {
  subnet_id      = aws_subnet.SUB-4-VPCIP8000N8.id
  route_table_id = aws_route_table.Route-VPCIP8000N8.id
}

#SG (ingress is incoming traffic , egress is outgoing traffic)
resource "aws_security_group" "SG_VPCIP8000N8" {
  name        = "SG_VPCIP8000N8"
  description = "Allow All traffic"
  vpc_id      = "${aws_vpc.VPCIP8000N8.id}"

  tags = {
    Name = "SG_VPCIP8000N8"
  }
}

resource "aws_security_group_rule" "ICMP" {
  type              = "ingress"
  description       = var.ICMP-description[1] # come from variables.tf 
  from_port         = 0
  to_port           = "-1"
  protocol          = "icmp"
  cidr_blocks       = ["0.0.0.0/0"]
  ipv6_cidr_blocks  = ["::/0"]
  security_group_id = aws_security_group.SG_VPCIP8000N8.id
}

resource "aws_security_group_rule" "ICMP_Out" {
  type        = "egress"
  description = var.ICMP-description[1] # come from variables.tf 
  from_port   = 0
  to_port     = "-1"
  protocol    = "icmp"
  cidr_blocks = ["0.0.0.0/0"]
  security_group_id = aws_security_group.SG_VPCIP8000N8.id
}

resource "aws_security_group_rule" "TCP" {
  type        = "ingress"
  description = var.TCP-description["TCP-desc"] # come from variables.tf 
  from_port   = 0
  to_port     = 0
  #protocol   = "tcp"
  protocol    = "-1"
  cidr_blocks = ["0.0.0.0/0"]
  security_group_id = aws_security_group.SG_VPCIP8000N8.id
}

resource "aws_security_group_rule" "TCP_Out" {
  type        = "egress"
  description = var.TCP-description["TCP_Out-desc"] # come from variables.tf 
  from_port   = 0
  to_port     = 0
  protocol    = "-1"
  cidr_blocks = ["0.0.0.0/0"]
  security_group_id = aws_security_group.SG_VPCIP8000N8.id
}

resource "aws_instance" "JenSlave" {
  ami                         = "ami-0cea098ed2ac54925"
  count                       = 1
  key_name                    = aws_key_pair.KeyToConnect.key_name #name should be there in txt file
  instance_type               = "t2.micro"
  vpc_security_group_ids      = ["${aws_security_group.SG_VPCIP8000N8.id}"]
  subnet_id                   = aws_subnet.SUB-1-VPCIP8000N8.id
  # security_groups             = ["default"]
  associate_public_ip_address = true
  tags = {
    Name = "JenSlave"
  }

  user_data = <<-EOF
  #!/bin/bash
  hostnamectl set-hostname 'JenSlave'
  EOF
  #to git clone
  # sudo cat <<EOF_CAT1 > /root/.ssh/id_rsa
  # ${data.template_file.private_key.rendered}
  # EOF_CAT1
  # sleep 10
  # #JenMaster can connect
  # cat <<EOF_CAT2 >> /home/ec2-user/.ssh/authorized_keys
  # ${data.template_file.public_key.rendered}
  # EOF_CAT2
  # chmod 400 /root/.ssh/id_rsa
  # chmod 600 /home/ec2-user/.ssh/authorized_keys
  # sleep 40
  
  connection {
    type        = "ssh"
    user        = "ec2-user"
    #private_key = data.template_file.private_sshkey.rendered
    private_key = file("forssh.pem")
    host        = self.public_ip
    timeout     = "4m"
  }

  provisioner "file" {
    source      = "git_id_rsa.txt"
    destination = "/home/ec2-user/.ssh/id_rsa"
  }

  provisioner "file" {
    source      = "slave.sh"
    destination = "/tmp/slave.sh"
  }
  
  #Git Clone
  provisioner "remote-exec" {
    inline = [
      "sleep 15",
      "chmod 700 /home/ec2-user/.ssh/id_rsa",
      "chmod +x /tmp/slave.sh",     
      "echo '${file("id_rsa_pub.txt")}' >> /home/ec2-user/.ssh/authorized_keys",
      ". /tmp/slave.sh"
    ]
  }
}

resource "aws_instance" "JenMaster" {
  ami                         = "ami-0cea098ed2ac54925"
  count                       = 1
  key_name                    = aws_key_pair.KeyToConnect.key_name #name should be there in txt file
  instance_type               = "t2.micro"
  vpc_security_group_ids      = ["${aws_security_group.SG_VPCIP8000N8.id}"]
  subnet_id                   = aws_subnet.SUB-1-VPCIP8000N8.id
  # security_groups             = ["default"]
  associate_public_ip_address = true
  tags = {
    Name = "JenMaster"
  }

  user_data = <<-EOF
  #!/bin/bash
  hostnamectl set-hostname 'JenMaster'
  EOF
  #to git clone
  # sudo cat <<EOF_CAT1 > /root/.ssh/id_rsa
  # ${data.template_file.private_key.rendered}
  # EOF_CAT1
  # sleep 10
  # #JenMaster can connect
  # chmod 400 /root/.ssh/id_rsa
  # chmod 600 /home/ec2-user/.ssh/authorized_keys
  # sleep 40
  # cat <<EOF_CAT2 >> /home/ec2-user/.ssh/authorized_keys
  # ${data.template_file.public_key.rendered}
  # EOF_CAT2

  connection {
    type        = "ssh"
    user        = "ec2-user"
    #private_key = data.template_file.private_sshkey.rendered
    private_key = file("forssh.pem")
    host        = self.public_ip
    timeout     = "4m"
  }

  provisioner "file" {
    source      = "git_id_rsa.txt"
    destination = "/home/ec2-user/.ssh/id_rsa"
  }

  provisioner "file" {
    source      = "master.sh"
    destination = "/tmp/master.sh"
  }
  
  #Git Clone
  provisioner "remote-exec" {
    inline = [
      "sleep 15",
      "chmod 700 /home/ec2-user/.ssh/id_rsa",
      "chmod +x /tmp/master.sh",     
      "echo '${file("id_rsa_pub.txt")}' >> /home/ec2-user/.ssh/authorized_keys",
      "sleep 3",
      ". /tmp/master.sh"
    ]
  }
}

output "instance_JenMaster_public_ip" {
  description = "This will provide public ip of created instances"
  value = aws_instance.JenMaster[0].public_ip
}

output "instance_JenMaster_dns_id" {
  description = "This will provide public ip of created instances"
  value = "${aws_instance.JenMaster[0].public_dns} - ${aws_instance.JenMaster[0].id}"
}

output "instance_JenSlave_public_ip" {
  description = "This will provide public ip of created instances"
  value = aws_instance.JenSlave[0].public_ip
}

output "instance_JenSlave_dns_id" {
  description = "This will provide public ip of created instances"
  value = "${aws_instance.JenSlave[0].public_dns} - ${aws_instance.JenSlave[0].id}"
}

