export const Constant = {

    API_URL: 'https://projectapi.gerasim.in/api/Complaint/',
    DEPA_METHOD: {
        GET_PARENT_DEPA: 'GetParentDepartment',
        ADD_NEW_DEPA: 'AddNewDepartment',
        UPDATE_DEPA: 'UpdateDepartment',

    }

}