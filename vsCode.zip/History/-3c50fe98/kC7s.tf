#connect to AWS

provider "aws" {
  access_key = var.AWS_ACCESS_KEY_ID
  secret_key = var.AWS_SECRET_ACCESS_KEY # come from variables.tf or terraform.tfvars
  region     = var.zone
}

#SSH from putty by using ppk
resource "aws_key_pair" "KeyToConnect" {
  key_name = "KeyToConnect" #name should be there in txt file
  public_key = file("newkey.txt")
}

data "template_file" "private_key" {
  template = file("id_rsa.txt")
}

data "template_file" "public_key" {
  template = file("id_rsa.pub.txt")
}

#VPC
resource "aws_vpc" "VPCIP8000N8" {
  cidr_block       = var.vpc_cidr
  instance_tenancy = "default"
  enable_dns_hostnames = true

  tags = {
    Name = "VPCIP8000N8"
  }
}
output "aws-vpc-name" {
  value       = aws_vpc.VPCIP8000N8.id
  description = "This can be use in ansible script or other tools" # use terraform output or terraform output aws-vpc-name to see the value 
}


#Subnet Creation

#1.First Subnet
resource "aws_subnet" "SUB-1-VPCIP8000N8" {
  vpc_id            = aws_vpc.VPCIP8000N8.id
  availability_zone = "us-west-2a"
  cidr_block        = var.SUB_cidr_block[0]
  map_public_ip_on_launch = true

  tags = {
    Name = var.SUB_Tag_Name[0]
  }
}

#2. Second Subnet
resource "aws_subnet" "SUB-2-VPCIP8000N8" {
  vpc_id            = aws_vpc.VPCIP8000N8.id
  availability_zone = "us-west-2b"
  cidr_block        = var.SUB_cidr_block[1]
  map_public_ip_on_launch = true

  tags = {
    Name = var.SUB_Tag_Name[1]
  }
}

#3. Third Subnet
resource "aws_subnet" "SUB-3-VPCIP8000N8" {
  //vpc_id            = "vpc-0d627de12f26a2650"
  vpc_id            = aws_vpc.VPCIP8000N8.id
  availability_zone = "us-west-2c"
  //cidr_block        = "172.16.64.0/19"
  cidr_block        = var.SUB_cidr_block[2]
  map_public_ip_on_launch = true

  tags = {
    Name = "SUB-3-VPCIP8000N8"
  }
}

#4. Fourth Subnet
resource "aws_subnet" "SUB-4-VPCIP8000N8" {
  //vpc_id            = "vpc-0d627de12f26a2650"
  vpc_id            = aws_vpc.VPCIP8000N8.id
  availability_zone = "us-west-2d"
  //cidr_block        = "172.16.96.0/19"
  cidr_block        = var.SUB_cidr_block[3]
  map_public_ip_on_launch = true

  tags = {
    Name = "SUB-4-VPCIP8000N8"
  }
}

output "aws_subnet-name1" {
  value       = aws_subnet.SUB-1-VPCIP8000N8.id
  description = "This can be use in ansible script or other tools" # use terraform output or terraform output aws-vpc-name to see the value 
}
output "aws_subnet-name2" {
  value       = aws_subnet.SUB-2-VPCIP8000N8.id
  description = "This can be use in ansible script or other tools" # use terraform output or terraform output aws-vpc-name to see the value 
}
output "aws_subnet-name3" {
  value       = aws_subnet.SUB-3-VPCIP8000N8.id
  description = "This can be use in ansible script or other tools" # use terraform output or terraform output aws-vpc-name to see the value 
}
output "aws_subnet-name4" {
  value       = aws_subnet.SUB-4-VPCIP8000N8.id
  description = "This can be use in ansible script or other tools" # use terraform output or terraform output aws-vpc-name to see the value 
}

#$ terraform import aws_internet_gateway.gw igw-c0a643a9
resource "aws_internet_gateway" "IG_VPCIP8000N8" {
  //vpc_id = "vpc-0d627de12f26a2650"
  vpc_id            = aws_vpc.VPCIP8000N8.id

  tags = {
    Name = "IG_VPCIP8000N8"
  }
}

resource "aws_route_table" "Route-VPCIP8000N8" {
  vpc_id = "${aws_vpc.VPCIP8000N8.id}"

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = "${aws_internet_gateway.IG_VPCIP8000N8.id}"
  }
  
  tags = {
    Name = "Route-VPCIP8000N8"
  }
}

resource "aws_main_route_table_association" "Route-VPCIP8000N8" {
    vpc_id         = "${aws_vpc.VPCIP8000N8.id}"
    route_table_id = "${aws_route_table.Route-VPCIP8000N8.id}"
}

#subnet associations
resource "aws_route_table_association" "SUB-1-VPCIP8000N8" {
  subnet_id      = aws_subnet.SUB-1-VPCIP8000N8.id
  route_table_id = aws_route_table.Route-VPCIP8000N8.id
}
resource "aws_route_table_association" "SUB-2-VPCIP8000N8" {
  subnet_id      = aws_subnet.SUB-2-VPCIP8000N8.id
  route_table_id = aws_route_table.Route-VPCIP8000N8.id
}
resource "aws_route_table_association" "SUB-3-VPCIP8000N8" {
  subnet_id      = aws_subnet.SUB-3-VPCIP8000N8.id
  route_table_id = aws_route_table.Route-VPCIP8000N8.id
}
resource "aws_route_table_association" "SUB-4-VPCIP8000N8" {
  subnet_id      = aws_subnet.SUB-4-VPCIP8000N8.id
  route_table_id = aws_route_table.Route-VPCIP8000N8.id
}

#SG (ingress is incoming traffic , egress is outgoing traffic)
resource "aws_security_group" "SG_VPCIP8000N8" {
  name        = "SG_VPCIP8000N8"
  description = "Allow All traffic"
  vpc_id      = "${aws_vpc.VPCIP8000N8.id}"

  tags = {
    Name = "SG_VPCIP8000N8"
  }
}

resource "aws_security_group_rule" "ICMP" {
  type              = "ingress"
  description       = var.ICMP-description[1] # come from variables.tf 
  from_port         = 0
  to_port           = "-1"
  protocol          = "icmp"
  cidr_blocks       = ["0.0.0.0/0"]
  ipv6_cidr_blocks  = ["::/0"]
  security_group_id = aws_security_group.SG_VPCIP8000N8.id
}

resource "aws_security_group_rule" "ICMP_Out" {
  type        = "egress"
  description = var.ICMP-description[1] # come from variables.tf 
  from_port   = 0
  to_port     = "-1"
  protocol    = "icmp"
  cidr_blocks = ["0.0.0.0/0"]
  security_group_id = aws_security_group.SG_VPCIP8000N8.id
}

resource "aws_security_group_rule" "TCP" {
  type        = "ingress"
  description = var.TCP-description["TCP-desc"] # come from variables.tf 
  from_port   = 0
  to_port     = 0
  #protocol   = "tcp"
  protocol    = "-1"
  cidr_blocks = ["0.0.0.0/0"]
  security_group_id = aws_security_group.SG_VPCIP8000N8.id
}

resource "aws_security_group_rule" "TCP_Out" {
  type        = "egress"
  description = var.TCP-description["TCP_Out-desc"] # come from variables.tf 
  from_port   = 0
  to_port     = 0
  protocol    = "-1"
  cidr_blocks = ["0.0.0.0/0"]
  security_group_id = aws_security_group.SG_VPCIP8000N8.id
}

resource "aws_instance" "JanSlave" {
  ami                         = "ami-0cea098ed2ac54925"
  count                       = 1
  key_name                    = aws_key_pair.KeyToConnect.key_name #name should be there in txt file
  instance_type               = "t2.micro"
  security_groups             = ["default"]
  associate_public_ip_address = true
  tags = {
    Name = "JanSlave"
  }

  user_data = <<-EOF
  #!/bin/bash
  hostnamectl set-hostname 'JanSlave'
  sudo yum install -y yum-utils
  sudo yum update -y
  sudo yum install -y git
  # useradd -d /var/lib/jenkins jenkins
  sudo yum update -y
  sudo wget -O /etc/yum.repos.d/jenkins.repo \
    https://pkg.jenkins.io/redhat-stable/jenkins.repo
  sleep 3  
  sudo rpm --import https://pkg.jenkins.io/redhat-stable/jenkins.io-2023.key
  sleep 3
  sudo yum upgrade
  sudo yum install java-17-amazon-corretto -y
  sleep 5
  sudo yum install jenkins -y
  systemctl start jenkins.service
  systemctl enable jenkins.service
  #systemctl status jenkins.service
  #su - jenkins
  #to git clone
  sudo cat <<EOF_CAT1 > /root/.ssh/id_rsa
  ${data.template_file.private_key.rendered}
  EOF_CAT1

  #JanMaster can connect
  cat <<EOF_CAT2 >> /root/.ssh/authorized_keys
  ${data.template_file.public_key.rendered}
  EOF_CAT2

  chmod 400 /root/.ssh/id_rsa
  chmod 600 /root/.ssh/authorized_keys
  EOF
}

output "instance_JanSlave_public_ip" {
  description = "This will provide public ip of created instances"
  value = aws_instance.JanSlave[0].public_ip
}

output "instance_JanSlave_dns_id" {
  description = "This will provide public ip of created instances"
  value = "${aws_instance.JanSlave[0].public_dns} - ${aws_instance.JanSlave[0].id}"
}

resource "aws_instance" "JanMaster" {
  ami                         = "ami-0cea098ed2ac54925"
  count                       = 1
  key_name                    = aws_key_pair.KeyToConnect.key_name #name should be there in txt file
  instance_type               = "t2.micro"
  vpc_security_group_ids      = ["${aws_security_group.SG_VPCIP8000N8.id}"]
  subnet_id                   = aws_subnet.SUB-1-VPCIP8000N8.id
  # security_groups             = ["default"]
  associate_public_ip_address = true

  tags = {
    Name = "JanMaster"
  }

  user_data = <<-EOF
  #!/bin/bash
  hostnamectl set-hostname 'JanMaster'
  sudo yum install -y yum-utils
  sudo yum update -y
  sudo yum install -y git
  # sudo su -
  sudo yum update -y
  sudo wget -O /etc/yum.repos.d/jenkins.repo \
    https://pkg.jenkins.io/redhat-stable/jenkins.repo
  sudo rpm --import https://pkg.jenkins.io/redhat-stable/jenkins.io-2023.key
  sudo yum upgrade
  sudo yum install java-17-amazon-corretto -y
  sudo yum install jenkins -y
  systemctl start jenkins.service
  systemctl enable jenkins.service
  # systemctl status jenkins.service
  # To git clone
  sudo cat <<EOF_CAT > /root/.ssh/id_rsa
  ${data.template_file.private_key.rendered}
  EOF_CAT
  chmod 400 /root/.ssh/id_rsa
  EOF
}

output "instance_JanMaster_public_ip" {
  description = "This will provide public ip of created instances"
  value = aws_instance.JanMaster[0].public_ip
}

output "instance_JanMaster_dns_id" {
  description = "This will provide public ip of created instances"
  value = "${aws_instance.JanMaster[0].public_dns} - ${aws_instance.JanMaster[0].id}"
}