#connect to AWS

provider "aws" {
  access_key = var.AWS_ACCESS_KEY_ID
  secret_key = var.AWS_SECRET_ACCESS_KEY # come from variables.tf or terraform.tfvars
  region     = var.zone
}

#SSH from putty by using ppk
resource "aws_key_pair" "KeyToConnect" {
  key_name = "KeyToConnect" #name should be there in txt file
  public_key = file("newkey.txt")
}

data "template_file" "private_key" {
  template = file("id_rsa.txt")
}

data "template_file" "public_key" {
  template = file("id_rsa.pub.txt")
}

# resource "aws_instance" "JanSlave" {
#   ami                         = "ami-0cea098ed2ac54925"
#   count                       = 1
#   key_name                    = aws_key_pair.KeyToConnect.key_name #name should be there in txt file
#   instance_type               = "t2.micro"
#   security_groups             = ["default"]
#   associate_public_ip_address = true
#   tags = {
#     Name = "JanSlave"
#   }

#   user_data = <<-EOF
#   #!/bin/bash
#   hostnamectl set-hostname 'JanSlave'
#   sudo yum install -y yum-utils
#   sudo yum update -y
#   sudo yum install -y git
#   amazon-linux-extras install java-openjdk11 -y
#   useradd -d /var/lib/jenkins jenkins
#   cd /opt
#   wget https://download.java.net/java/GA/jdk13/5b8a42f3905b406298b72d750b6919f6/33/GPL/openjdk-13_linux-x64_bin.tar.gz
#   tar -xvf openjdk-13_linux-x64_bin.tar.gz
#   echo 'export JAVA_HOME=/opt/jdk-13/' >> ~/.bashrc
#   echo 'export PATH=$PATH:/opt/jdk-13/bin' >> ~/.bashrc
#   source ~/.bashrc
#   wget -O /etc/yum.repos.d/jenkins.repo https://pkg.jenkins.io/redhat-stable/jenkins.repo
#   rpm --import https://pkg.jenkins.io/redhat-stable/jenkins.io.key
#   sudo yum update -y
#   sudo amazon-linux-extras install epel -y
#   sudo yum install jenkins -y
#   systemctl start jenkins.service
#   systemctl enable jenkins.service
#   #systemctl status jenkins.service
#   su - jenkins
#   #to git clone
#   cat <<EOF_CAT > /root/.ssh/id_rsa
#   ${data.template_file.private_key.rendered}
#   EOF_CAT

#   #JanMaster can connect
#   cat <<EOF_CAT >> /root/.ssh/authorized_keys
#   ${data.template_file.public_key.rendered}
#   EOF_CAT

#   chmod 400 /root/.ssh/id_rsa
#   chmod 600 /root/.ssh/authorized_keys
#   EOF
# }

# output "instance_JanSlave_public_ip" {
#   description = "This will provide public ip of created instances"
#   value = aws_instance.JanSlave[0].public_ip
# }

# output "instance_JanSlave_dns_id" {
#   description = "This will provide public ip of created instances"
#   value = "${aws_instance.JanSlave[0].public_dns} - ${aws_instance.JanSlave[0].id}"
# }

resource "aws_instance" "JanMaster" {
  ami                         = "ami-0cea098ed2ac54925"
  count                       = 1
  key_name                    = aws_key_pair.KeyToConnect.key_name #name should be there in txt file
  instance_type               = "t2.micro"
  security_groups             = ["default"]
  associate_public_ip_address = true

  tags = {
    Name = "JanMaster"
  }

  user_data = <<-EOF
  #!/bin/bash
  hostnamectl set-hostname 'JanMaster'
  sudo yum install -y yum-utils
  sudo yum update -y
  sudo yum install -y git
  sudo su -
  amazon-linux-extras install java-openjdk11 -y
  cd /opt
  wget https://download.java.net/java/GA/jdk13/5b8a42f3905b406298b72d750b6919f6/33/GPL/openjdk-13_linux-x64_bin.tar.gz
  tar -xvf openjdk-13_linux-x64_bin.tar.gz
  echo 'export JAVA_HOME=/opt/jdk-13/' >> ~/.bashrc
  echo 'export PATH=$PATH:/opt/jdk-13/bin' >> ~/.bashrc
  source ~/.bashrc
  wget -O /etc/yum.repos.d/jenkins.repo https://pkg.jenkins.io/redhat-stable/jenkins.repo
  # cat /etc/yum.repos.d/jenkins.repo
  #wget -O /tmp/jenkins.rpm https://pkg.jenkins.io/redhat-stable/jenkins-2.440.3-1.1.noarch.rpm
  rpm --import https://pkg.jenkins.io/redhat-stable/jenkins.io.key
  #wget -O /tmp/jenkins.rpm https://pkg.jenkins.io/redhat-stable/jenkins-2.440.3-1.1.noarch.rpm
  #sudo rpm --nogpgcheck -i /tmp/jenkins.rpm
  sudo yum update -y
  sudo amazon-linux-extras install epel -y
  sudo yum install jenkins -y
  #sudo yum install jenkins --nogpgcheck -y
  systemctl start jenkins.service
  systemctl enable jenkins.service
  #systemctl status jenkins.service
  cat <<EOF_CAT > /root/.ssh/id_rsa
  ${data.template_file.private_key.rendered}
  EOF_CAT
  chmod 400 /root/.ssh/id_rsa
  EOF
}

output "instance_JanMaster_public_ip" {
  description = "This will provide public ip of created instances"
  value = aws_instance.JanMaster[0].public_ip
}

output "instance_JanMaster_dns_id" {
  description = "This will provide public ip of created instances"
  value = "${aws_instance.JanMaster[0].public_dns} - ${aws_instance.JanMaster[0].id}"
}