
#$fname = Read-Host "Enter File Name"
$fileName = "C:\Users\HARSHIT.ARANYA\Documents\Harshit\eLearning\SSIS\sample_data.txt"
cls
Write-Host "Should be : Lines = 55 | Words = 426 | Characters = 258500"
Get-Content $fileName |Measure-Object -Character -Line -Word

#Next
$str = Get-Content $fileName -ReadCount 1
$cDate = Get-Date -Format "yyyy-MM-dd"
Write-Host $cDate;
if ($str -match $cDate ) { Write-Host "OKAY" -ForegroundColor Darkgreen -BackgroundColor white } else { Write-Host "Not Found" -ForegroundColor red -BackgroundColor white }

#Next
$str = Get-Content $fileName -ReadCount 1
$words = Get-Content "C:\Users\HARSHIT.ARANYA\Documents\Harshit\eLearning\SSIS\MySSIS_Text\MySSIS_Text\words.txt"
foreach( $word in $words ) { Write-Host $word; if ($str -match $word ) { Write-Host "OKAY" -ForegroundColor Darkgreen -BackgroundColor white } else { Write-Host "Not Found" -ForegroundColor red -BackgroundColor white }}

#Next

$counts = Get-Content "C:\Users\HARSHIT.ARANYA\Documents\Harshit\eLearning\SSIS\MySSIS_Text\MySSIS_Text\count.txt"
$FileContent = Get-Content $fileName
foreach( $count in $counts ){$Matches = Select-String -InputObject $FileContent -Pattern $count -AllMatches; Write-Host $count; $Matches.Matches.Count}

#Next

$myfile = Get-Content -Path $fileName
$i = 0
$myfile | ForEach-Object {
    $ln = $_ | Measure-Object -Line
    [Int]$totalLn = $ln.lines
    $total = $i + [Int]$totalLn
    if($_ -cmatch'[\0]'){   
        Write-Output $_
	Write-Host $total  
    }elseif($_ -cmatch'[\n]'){
	Write-Output $_
	Write-Host $total
    }elseif($_ -cmatch'[\r]'){
	Write-Output $_
	Write-Host $total
    }elseif($_ -cmatch'[\t]'){
	Write-Output $_
	Write-Host $total
    }
    $i++
}
Write-host "END"