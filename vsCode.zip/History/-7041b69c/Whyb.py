#1
# In Python 3, the correct import is tkinter not Tkinter. Tkinter was the name of the module used for Python 2
import tkinter as tk

# ttk is the Python binding to the newer "themed widgets" added in Tk version 8.5
from tkinter import ttk

root = tk.Tk()
ttk.Label(root, text="Hello, World!", padding=(30, 10)).pack()

root.mainloop()

#2
import tkinter as tk
from tkinter import ttk


def greet():
    print("Hello, World!")


root = tk.Tk()
root.title("Hello")

greet_button = ttk.Button(root, text="Greet", command=greet)
greet_button.pack(side="left", fill="x", expand=True)

quit_button = ttk.Button(root, text="Quit", command=root.destroy)
quit_button.pack(side="left", fill="x", expand=True)  # could use side="right"

root.mainloop()

#3
