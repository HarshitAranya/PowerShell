import { HttpClient } from '@angular/common/http';
import { ChangeDetectionStrategy, Component, OnInit, inject } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-add-employee',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './add-employee.component.html',
  styleUrl: './add-employee.component.css',
  // changeDetection: ChangeDetectionStrategy.OnPush //change it to load data 
})

export class AddEmployeeComponent implements OnInit {

  changeDetectionTest:string = "Before"
  http = inject(HttpClient);
  userList:any [] = [];

  ngOnInit(): void {
    this.http.get("https://jsonplaceholder.typicode.com/users").subscribe( (res:any)=>{
      this.userList = res;
      this.changeDetectionTest = "After"
    })
  }


}
