import { HttpClient } from '@angular/common/http';
import { ChangeDetectionStrategy, Component, OnInit, inject } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-add-employee',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './add-employee.component.html',
  styleUrl: './add-employee.component.css'
})

export class AddEmployeeComponent implements OnInit {

  http = inject(HttpClient);
  userList:any [] = [];

  OnInit(){
    this.http.get("").subscribe( (res:any)=>{
      this.userList = res;
    })
  }

}
