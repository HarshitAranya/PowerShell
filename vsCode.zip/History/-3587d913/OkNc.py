import selenium
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
# Set up Chrome options
chrome_options = Options()
chrome_options.add_argument("--start-fullscreen")  # Open Chrome in full-screen mode
# Set up the driver (automatically manages ChromeDriver)
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
# Navigate to the desired URL
driver.get("https://www.google.com/")
search_box = driver.find_element(By.NAME, "q")
search_box.send_keys("Harshit")
search_box.send_keys(Keys.RETURN)
input("Press Enter to exit and close the browser...")
# Optional: You can interact with elements on the page here if needed
# Close the browser after some time (optional)
driver.quit()