import { Router } from '@angular/router';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  userObj:any = {
    userName:'',
    password:''
  }
  
  router = inject(Router);
  onClick(){
    if(this.userObj.userName == 'admin' && this.userObj.password == "1234"){
      alert("Logged In");
      this.router.navigateByUrl('add_emp');
    }
  }

}
