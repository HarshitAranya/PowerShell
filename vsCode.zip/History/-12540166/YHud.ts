import { Router } from '@angular/router';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  // userObj:any = {
  //   userName:'',
  //   password:''
  // }

  userObj:any = {
    EmailId:'',
    Password:''
  }
  
  router = inject(Router);
  http = inject(HttpClient)

  onClick(){
    debugger;
    this.http.post("https://projectapi.gerasim.in/api/UserApp/login", this.userObj).subscribe((res:any)=>{
      if(res.result){
        debugger;
        alert("Logged In");
        localStorage.setItem('loginUser', this.userObj.EmailId)
        this.router.navigateByUrl('add_emp');
      }else{
        debugger;
        alert("Login Failed");
      }
    })
    // if(this.userObj.userName == 'admin' && this.userObj.password == "1234"){
    //   alert("Logged In");
    //   localStorage.setItem('loginUser', this.userObj.EmailId)
    //   this.router.navigateByUrl('add_emp');
    // }
  }

}
