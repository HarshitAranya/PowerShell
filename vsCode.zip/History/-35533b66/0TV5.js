// script.js

document.addEventListener('DOMContentLoaded', function() {
    const items = document.querySelectorAll('#items li');
    const pagination = document.getElementById('pagination');
    const itemsPerPageSelect = document.getElementById('itemsPerPageSelect');

    // let itemsPerPage = parseInt(itemsPerPageSelect.value, 10);
    let itemsPerPage = parseInt(3, 10);

    function showPage(page, itemsPerPage) {
        // Hide all items
        items.forEach((item, index) => {
            item.style.display = 'none';
        });

        // Show items for the current page
        const start = (page - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        for (let i = start; i < end; i++) {
            if (items[i]) {
                items[i].style.display = 'block';
            }
        }

        // Update active class on pagination buttons
        const buttons = pagination.querySelectorAll('button');
        buttons.forEach(button => {
            button.classList.remove('active');
        });
        buttons[page - 1].classList.add('active');
    }

    function createPagination(itemsPerPage) {
        pagination.innerHTML = ''; // Clear existing pagination
        const pageCount = Math.ceil(items.length / itemsPerPage);

        for (let i = 1; i <= pageCount; i++) {
            const button = document.createElement('button');
            button.textContent = i;
            button.addEventListener('click', () => {
                showPage(i, itemsPerPage);
            });
            pagination.appendChild(button);
        }
    }

    itemsPerPageSelect.addEventListener('change', (event) => {
        itemsPerPage = parseInt(event.target.value, 10);
        createPagination(itemsPerPage);
        showPage(1, itemsPerPage); // Show the first page with new items per page
    });

    // Initial setup
    createPagination(itemsPerPage);
    showPage(1, itemsPerPage); // Show the first page initially
});
