import { AsyncPipe, DatePipe, JsonPipe, LowerCasePipe, TitleCasePipe, UpperCasePipe } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { interval, Observable, map } from 'rxjs';
import { MyNApipePipe } from '../../my-napipe.pipe';
import { DepartmentService } from '../../services/department.service';

@Component({
  selector: 'app-my-pipes',
  standalone: true,
  imports: [FormsModule, LowerCasePipe, 
    JsonPipe, AsyncPipe, MyNApipePipe,
    UpperCasePipe, TitleCasePipe, DatePipe],
  templateUrl: './my-pipes.component.html',
  styleUrl: './my-pipes.component.css'
})
export class MyPipesComponent {

  uper: string = 'abc';
  lower: string = 'ABC';
  title: string = 'aHaBaN my name harshit';

  currentDate: Date = new Date();

  student: any = {
    name: 'harshit',
    city: 'Indore',
    empId: 1234,
    status: ''
  }

  currentTime: Observable<Date> = new Observable<Date>;
  currentRole: string = '';
  constructor(private deptService: DepartmentService){
    this.currentTime = interval(1000).pipe(map( ()=> new Date()));
    this.deptService.onRoleChange$.subscribe( (role:string)=>{
      debugger;
      this.currentRole = role;
    } )
  }


}
