import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-my-pipes',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './my-pipes.component.html',
  styleUrl: './my-pipes.component.css'
})
export class MyPipesComponent {

  uper: string = '';
  lower: string = '';
  title: string = '';

  currentDate: Date = new Date();

}
