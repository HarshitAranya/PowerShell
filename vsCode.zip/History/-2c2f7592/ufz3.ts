import { DatePipe, LowerCasePipe, TitleCasePipe, UpperCasePipe } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-my-pipes',
  standalone: true,
  imports: [FormsModule, LowerCasePipe, UpperCasePipe, TitleCasePipe, DatePipe],
  templateUrl: './my-pipes.component.html',
  styleUrl: './my-pipes.component.css'
})
export class MyPipesComponent {

  uper: string = 'abc';
  lower: string = 'ABC';
  title: string = 'aHaBaN my name harshit';

  currentDate: Date = new Date();


}
