import { DatePipe, LowerCasePipe, TitleCasePipe, UpperCasePipe } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-my-pipes',
  standalone: true,
  imports: [FormsModule, LowerCasePipe, UpperCasePipe, TitleCasePipe, DatePipe],
  templateUrl: './my-pipes.component.html',
  styleUrl: './my-pipes.component.css'
})
export class MyPipesComponent {

  uper: string = '';
  uperb: string = '';
  lower: string = '';
  title: string = '';

  currentDate: Date = new Date();


}
