# python -m venv myenv
# .\env_name\Scripts\Activate
# deactivate