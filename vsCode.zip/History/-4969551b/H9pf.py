def wish():
    print('Happy Birth Day to You ')

wish()


