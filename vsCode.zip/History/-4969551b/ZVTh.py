def wish():
    print(f'Happy Birth Day to You ')

wish()


