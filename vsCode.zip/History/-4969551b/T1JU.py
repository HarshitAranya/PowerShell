# def wish(name):
#   print(f"Many Many Happy Returns of the Day {name}")

# wish("Dhaval Bhai")

# s = 'HelloWorld'
# print(s.isalnum())

def containsLetterAndNumber(input):
    return input.isalnum() and not input.isalpha() and not input.isdigit()

x = containsLetterAndNumber('abcd')
print(x)