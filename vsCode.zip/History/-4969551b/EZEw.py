def wish():
    return 'Happy Birth Day to You '

wish()


