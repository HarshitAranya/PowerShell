def wish(name):
    print(f'Happy Birth Day to You {name}')

wish("Dhaval Bhai")


