def wish(name):
  print(f"Many Many Happy Returns of the Day {name}")

wish("Dhaval Bhai")