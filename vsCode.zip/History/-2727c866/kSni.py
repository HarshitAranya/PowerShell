# Installation
# CD name_of_env
# pip install pywin32-308-cp312-cp312-win_amd64.whl
# pip install --no-index --find-links=./ .\setuptools-75.8.0-py3-none-any.whl
# pip install --no-index --find-links=./ .\altgraph-0.17.4-py2.py3-none-any.whl
# pip install --no-index --find-links=./ .\packaging-24.2-py3-none-any.whl
# NA pip install --no-index --find-links=./ .\pefile-2024.8.26-py3-none-any.whl
# pip uninstall pefile
# pip install --no-index --find-links=./ .\pefile-2023.2.7-py3-none-any.whl
# pip install --no-index --find-links=./ .\pywin32_ctypes-0.2.3-py3-none-any.whl
# pip install --no-index --find-links=./ .\pyinstaller-6.11.1-py3-none-win_amd64.whl #--proxy="" --timeout 30
# pyinstaller --onefile readOCR_Doc.py

import os
import sys
import datetime
import time
import win32com.client

# Get the directory where the .exe file is located
current_directory = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.dirname(os.path.realpath(__file__))

# List all .docx files in the directory
docx_files = [f for f in os.listdir(current_directory) if f.endswith('.docx')]

# If there are .docx files in the directory
if docx_files:
    # Get the latest .docx file based on the modification time
    latest_file = max(docx_files, key=lambda f: os.path.getmtime(os.path.join(current_directory, f)))
    latest_file_path = os.path.join(current_directory, latest_file)
    
    # Print or use the path of the latest file
    print(f"The latest .docx file is: {latest_file}")
    print(f"File path: {latest_file_path}")
else:
    print("No .docx files found in the directory.")

current_directory = os.getcwd()
# file_path = os.path.join(current_directory, "wordfile.docx")
currentDate = datetime.datetime.now()
# Check if the file exists
if os.path.exists(latest_file_path):
    # Get the modification time
    mod_time = os.path.getmtime(latest_file_path)
    mod_date = datetime.datetime.fromtimestamp(mod_time)
    # Convert the timestamp into a readable format
    today = currentDate.strftime('%d-%m-%Y')
    fileDate = mod_date.strftime('%d-%m-%Y')
    print(f'Today is {today} and file date is {fileDate}')
else:
    print(f"File '{latest_file_path}' does not exist.")


temp_file_path = f"~${os.path.basename(latest_file_path)}"

# Check if the temporary file exists (meaning the document is open)
if os.path.exists(temp_file_path):
    print(f"The file {latest_file_path} is currently open.")
    time.sleep(10)
    exit()
else:
    word = win32com.client.Dispatch("Word.Application")
    word.Visible = False
    try:
        doc = word.Documents.Open(latest_file_path)
    except Exception as e:
        print(f"Error opening document: {e}")
        word.Quit()


# Launch Word in the background (invisible)
# word = win32com.client.Dispatch("Word.Application")
# word.Visible = False  # Keep Word invisible


# Open the Word document
# doc = word.Documents.Open(r"C:\Harshit\eLearning\Python\DevOps\wordfile.docx")
# word.Quit()
# doc = word.Documents.Open(latest_file_path)

# prange = [5,6,30,31,32,33,59,60,67,68,70,71,72,190,191,192,193,242,243]
# prange = [*range(5, 11), *range(30, 41), *range(58, 75), *range(188, 196), *range(235, 249)]
paragraph_dict = {}
# Loop through all paragraphs and print index and text
x=1
for index, paragraph in enumerate(doc.Paragraphs, start=1):
    # if index in prange:
    ptext = paragraph.Range.Text.strip()
    ptext = ptext.replace('\r', '').replace('\x07', '')
    paragraph_dict[x] = ptext
    x += 1

# print(paragraph_dict)

type = []
startEndDate = []
executionFiles = []
sqlFiles = []
# vCount = len(paragraph_dict)
# print(vCount)
startKey = 1
endKey = 2
deploymentDate = "Not found"
ocrNO = "Not found"
deploymentBy = "Not found"
gitNo = "Not found"
csdNo = "Not found"
rocrType = "Not found"
startDate = "Not found"
endDate = "Not found"

for key, value in paragraph_dict.items():
    # print(f"{key}: {value}")
    if "Reference" in value:
        # print(f"{key}: {value}")
        ocrNO = paragraph_dict[key+1]
        # print(ocrNO)

    if "Change Deployment" in value:
        # print(f"{key}: {value}")
        deploymentDate = paragraph_dict[key+1]
        # print(deploymentDate)
        
    if "Developed By" in value:
        # print(f"{key}: {value}")
        deploymentBy = paragraph_dict[key+1]
        # print(deploymentBy)
    
    if "Commit Number" in value:
        # print(f"{key}: {value}")
        gitNo = paragraph_dict[key+1]
        # print(gitNo)

    if "CSD reference" in value:
        # print(f"{key}: {value}")
        csdNo = paragraph_dict[key+1]
        # print(csdNo)
    
    if "Manual Treatment" in value:
        # print(f"{key}: {value}")
        for i in range(key, key+5):
            # print(paragraph_dict[i])
            type.append(paragraph_dict[i])

# print(type)

    if "DETAILS OF CHANGE DEPLOYMENT INTO PRODUCTION" in value:
        # print(f"{key}: {value}")
        for i in range(key, (key+7)):
            # print(paragraph_dict[i])
            startEndDate.append(paragraph_dict[i])

# print(startEndDate)

    if "IMPLEMENTATION PLAN (Add Rows as Necessary)" in value:
        # print(f"{key}: {value}")
        startKey = key

    if "BACK OUT / ROLL BACK PLAN" in value:
        # print(f"{key}: {value}")
        endKey = key

for i in range(startKey, endKey):
    # print(paragraph_dict[i])
    executionFiles.append(paragraph_dict[i])

# print(executionFiles)
        
for box in type:
    if "☒ - Yes" in box:
        rocrType = "Manual"
        # print(rocrType)
   
    if "☒ - No" in box:
        rocrType = "Auto"
        # print(rocrType) 

for seDate in startEndDate:
    if "Start Date" in seDate:
        startDate = startEndDate[startEndDate.index(seDate) + 1]
        # print(startDate)
  
    if "End Date" in seDate:
        endDate = startEndDate[startEndDate.index(seDate) + 1]
        # print(endDate)  
        
for sql in executionFiles:
    if ".sql" in sql:
        sqlFiles.append(sql)

print("----------------------------------------------")
# print(sqlFiles)

if(deploymentDate):
    print(f"Deployment Date : {deploymentDate}")
if(deploymentBy):
    print(f"Deployment By : {deploymentBy}")
if(ocrNO):
    print(f"OCR No. : {ocrNO}")
if(rocrType):
    print(f"ROCR Type : {rocrType}")
if(startDate):
    print(f"Start Date : {startDate}")
if(endDate):
    print(f"End Date : {endDate}")
if(csdNo):
    print(f"CSD No. : {csdNo}")
if(gitNo):
    print(f"Git No. : {gitNo}")
if(ocrNO and csdNo and gitNo):
    print(f"For Jenkins : {ocrNO},{csdNo},{gitNo}")
if(executionFiles):
    print("Execution Files :")

for x in sqlFiles:
    print(x.replace("\x0b", "\n"))
print("----------------------------------------------")
# Close the document and quit Word
doc.Close(False)  # False means don't save changes
word.Quit()
# Wait for 30 seconds before exiting
# time.sleep(10)
exit()


# doc.Close(False)  # False means don't save changes
# word.Quit()
# print("Testing end here")
# exit()
