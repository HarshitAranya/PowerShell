import { JsonPipe } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive',
  standalone: true,
  imports: [ReactiveFormsModule, JsonPipe],
  templateUrl: './reactive.component.html',
  styleUrl: './reactive.component.css'
})
export class ReactiveComponent {

  studentForm: FormGroup = new FormGroup(
    {
      firstName: new FormControl([Validators.required, Validators.minLength(4)]),
      lastName: new FormControl("Default"),
      userName: new FormControl("Default", [Validators.email]),
      city: new FormControl(),
      state: new FormControl("",[Validators.required, Validators.minLength(4)]),
      zipCode: new FormControl(""),
      isActiveTerms: new FormControl([Validators.required]),
    }
  );

  formValue: any;

  onSave(){
    this.formValue = this.studentForm.value;
  }

  onReset(){
    this.formValue = 'Pending';
  }

}
