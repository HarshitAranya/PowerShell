import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-reactive',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './reactive.component.html',
  styleUrl: './reactive.component.css'
})
export class ReactiveComponent {

  studentForm: FormGroup = new FormGroup(
    {
      firstName: new FormControl(),
      lastName: new FormControl(),
      userName: new FormControl(),
      city: new FormControl(),
      state: new FormControl(),
      zipCode: new FormControl(),
      isActiveTerms: new FormControl(),
    }
  );

}
