import { Component, OnInit, DoCheck, AfterViewInit, AfterViewChecked, AfterContentInit, AfterContentChecked, OnDestroy, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-lifecycle-event',
  standalone: true,
  imports: [],
  templateUrl: './lifecycle-event.component.html',
  styleUrl: './lifecycle-event.component.css'
})
export class LifecycleEventComponent implements OnInit, DoCheck, AfterViewInit, AfterViewChecked, AfterContentInit, AfterContentChecked, OnDestroy, OnChanges {

  constructor(){
    console.log("This constructor automatically call on page load");
    // alert('I am constructed from constructer');
  }

  ngOnInit(): void {
    console.log("This ngOnInit automatically call on page load");
    // alert('I am comming after loas components and after constructer');
  }

  ngDoCheck(): void {
    console.log("ngAfterContentInit");
    // alert('ngDoCheck');
  }

  ngAfterViewInit(): void {
    console.log("ngAfterContentInit");
    // alert('ngAfterViewInit');
  }

  ngAfterViewChecked(): void {
    console.log("ngAfterContentInit");
    // alert('ngAfterViewChecked');
  }

  ngAfterContentInit(): void {
    console.log("ngAfterContentInit");
    // alert('ngAfterContentInit');
  }

  ngAfterContentChecked(): void {
    console.log("ngAfterContentChecked");
    // alert('ngAfterContentChecked');
  }

  ngOnDestroy(): void {
    console.log("ngOnDestroy");
    // alert('ngOnDestroy');
  }

  ngOnChanges(changes: SimpleChanges): void {
    
  }
}
