import { Component, OnInit, DoCheck, AfterViewInit, AfterViewChecked, AfterContentInit, AfterContentChecked, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-lifecycle-event',
  standalone: true,
  imports: [],
  templateUrl: './lifecycle-event.component.html',
  styleUrl: './lifecycle-event.component.css'
})
export class LifecycleEventComponent implements OnInit, DoCheck, AfterViewInit, AfterViewChecked, AfterContentInit, AfterContentChecked, OnDestroy {

  constructor(){
    console.log("This will automatically call on page load");
    alert('I am constructed from constructer');
  }

  ngOnInit(): void {
    console.log("This will automatically call on page load");
    alert('I am comming after loas components and after constructer');
  }

  ngDoCheck(): void {
    
  }

  ngAfterViewInit(): void {
    
  }

  ngAfterViewChecked(): void {
    
  }

  ngAfterContentInit(): void {
    
  }

  ngAfterContentChecked(): void {
    
  }

  ngOnDestroy(): void {
    
  }
}
