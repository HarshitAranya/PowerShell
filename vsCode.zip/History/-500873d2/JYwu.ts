import { Component } from '@angular/core';

@Component({
  selector: 'app-data-binding',
  standalone: true,
  imports: [],
  templateUrl: './data-binding.component.html',
  styleUrl: './data-binding.component.css'
})
export class DataBindingComponent {

  courseName: string = "Angular 18";
  inputType = "text";
  rollNo: number = 123;
  inIndian: boolean = false;
  currentDate: Date = new Date();
  myClass1: string = "col-4 bg-success"
  myClass2: string = "col-4"

  constructor(){

  }

  showAlert(message: string){
    alert(message)
  }

  changeName(message1: string){
    this.courseName = message1
  }

}
