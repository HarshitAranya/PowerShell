import { Component, signal, Signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-data-binding',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './data-binding.component.html',
  styleUrl: './data-binding.component.css'
})
export class DataBindingComponent {

  courseName: string = "Angular 18";
  inputType = "text";
  rollNo: number = 123;
  inIndian: boolean = false;
  currentDate: Date = new Date();
  myClass1: string = "col-4 bg-success";
  myClass2: string = "col-4";

  firstName = signal("Harshit Aranya");

  constructor(){

  }

  showAlert(message: string){
    alert(message)
  }

  changeName(){
    this.courseName = "Python"
  }

}
