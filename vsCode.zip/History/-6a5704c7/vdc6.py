# import docx
# print(docx.__version__)

import site
print(site.getsitepackages())  # System-wide site-packages
print(site.getusersitepackages())  # User-specific site-packages