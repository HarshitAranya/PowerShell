from python-docx import docx
print(docx.__version__)