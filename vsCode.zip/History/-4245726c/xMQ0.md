echo -n 'securepassword' | base64
