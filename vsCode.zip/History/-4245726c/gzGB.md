echo -n 'securepassword' | base64
echo -n 'dbuser' | base64

DB_USER=$(cat /etc/secrets/DB_USER)
DB_PASSWORD=$(cat /etc/secrets/DB_PASSWORD)
