import os
import datetime
from docx import Document

current_directory = os.getcwd()
file_path = os.path.join(current_directory, "wordfile.docx")
currentDate = datetime.datetime.now()

# Check if the file exists
if os.path.exists(file_path):
    # Get the modification time
    mod_time = os.path.getmtime(file_path)
    mod_date = datetime.datetime.fromtimestamp(mod_time)
    # Convert the timestamp into a readable format
    today = currentDate.strftime('%d-%m-%Y')
    fileDate = mod_date.strftime('%d-%m-%Y')
    print(f'Today is {today} and file date is {fileDate}')
else:
    print(f"File '{file_path}' does not exist.")

# Open the Word document using python-docx
doc = Document(file_path)

# Define the paragraph range to extract
prange = [*range(5, 11), *range(30, 41), *range(58, 75), *range(188, 196), *range(235, 249)]
paragraph_dict = {}
exit()
# Loop through all paragraphs and store the text in the dictionary
x = 1
for index, paragraph in enumerate(doc.paragraphs, start=1):
    print(f"Paragraph {index}: {paragraph.text}")
    if index in prange:
        ptext = paragraph.text.strip()
        ptext = ptext.replace('\r', '').replace('\x07', '')
        paragraph_dict[x] = ptext
        x += 1


type = []
startEndDate = []
executionFiles = []
sqlFiles = []
vCount = len(paragraph_dict)

# Process the paragraph dictionary
for key, value in paragraph_dict.items():
    if "Reference" in value:
        ocrNO = paragraph_dict[key+1]
    if "Change Deployment" in value:
        deploymentDate = paragraph_dict[key+1]
    if "Developed By" in value:
        deploymentBy = paragraph_dict[key+1]   
    if "Commit Number" in value:
        gitNo = paragraph_dict[key+1]
    if "CSD reference" in value:
        csdNo = paragraph_dict[key+1]  
    if "Manual Treatment" in value:
        for i in range(key, len(value)):
            type.append(paragraph_dict[i])
    if "DETAILS OF CHANGE DEPLOYMENT INTO PRODUCTION" in value:
        for i in range(key, (key+8)):
            startEndDate.append(paragraph_dict[i])
    if "Activity" in value:
        for i in range(key, vCount):
            executionFiles.append(paragraph_dict[i])

# Process the 'type' box values
for box in type:
    if "☒ - Yes" in box:
        rocrType = "Manual"
    if "☒ - No" in box:
        rocrType = "Auto"

# Extract start and end dates
for seDate in startEndDate:
    if "Start Date" in seDate:
        startDate = startEndDate[startEndDate.index(seDate) + 1]
    if "End Date" in seDate:
        endDate = startEndDate[startEndDate.index(seDate) + 1]

# Filter for SQL files
for sql in executionFiles:
    if ".sql" in sql:
        sqlFiles.append(sql)

# Output results
print(f"Deployment Date : {deploymentDate}")
print(f"Deployment By : {deploymentBy}")
print(f"OCR No. : {ocrNO}")
print(f"ROCR Type : {rocrType}")
print(f"Start Date : {startDate}")
print(f"End Date : {endDate}")
print(f"CSD No. : {csdNo}")
print(f"Git No. : {gitNo}")
print(f"For Jenkins : {ocrNO},{csdNo},{gitNo}")
print("Execution Files :")
for x in sqlFiles:
    print(x.replace("\x0b", "\n"))
