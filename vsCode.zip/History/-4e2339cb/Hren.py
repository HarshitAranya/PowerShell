import os
import datetime

from docx import Document
from docx.shared import Inches
# Get the current working directory
file_path = "wordfile.docx"


doc = Document(file_path)

def read_worddata(tableNo):
    table = doc.tables[tableNo]  # Access the table by its index (starts at 0)
    all_cells_text = []
    # Iterate through each row in the table
    for row_idx, row in enumerate(table.rows):
        row_text = []  # List to store text from each cell in a row
        seen_cells = set()  # Set to track already processed cell text

        for col_idx, cell in enumerate(row.cells):
            cell_text = cell.text.strip()  # Strip any leading/trailing whitespace
  
            if cell_text and cell_text not in seen_cells:  # Only add non-empty unique text
                row_text.append(cell_text)
                seen_cells.add(cell_text)  # Mark this cell text as processed
                    
        if row_text:  # Only append the row if there is non-empty content
            all_cells_text.append(row_text)
            
    return all_cells_text

# Example usage
tableThree = read_worddata(2) 
# Print the content of the first row
tableFive_row_four = tableThree[3]

print(tableFive_row_four)

tableFour = read_worddata(3)  # Get all data from the 4th table (index starts at 0)
tableFour_row_three = tableFour[2]
tableFour_row_four = tableFour[3]
tableFour_row_five = tableFour[4]
tableFour_row_six = tableFour[5]

print(tableFour_row_three)
print(tableFour_row_four)
print(tableFour_row_five)

print(tableFour_row_six) # checkbox

tableSix = read_worddata(5)
print(tableSix[1])


# Read through each paragraph in the document
paragraph_index = 15
for paragraph in doc.paragraphs:
    # print(paragraph.Range.Text.strip())  # Print each paragraph's text
    # print(f"Paragraph {paragraph_index}: {paragraph.Range.Text.strip()}")
    if "☒" in paragraph.text:
        print("Checked box found:", paragraph.text)
    elif "☐" in paragraph.text:
        print("Unchecked box found:", paragraph.text)


# print(checked)

def read_worddata(tableNo):
    table = doc.tables[3]  # Access the table by its index (starts at 0)
    checked_boxes = []  
    all_cells_text = []
    checked_symbol = "Yes, if there are any manual steps as part of the deployment"
    # Iterate through each row in the table
    for row_idx, row in enumerate(table.rows):
        row = table.rows[5]
        print(row_idx)
        row_text = []  # List to store text from each cell in a row
        seen_cells = set()  # Set to track already processed cell text

    for col_idx, cell in enumerate(row.cells):
        cell = row.cells[1]
        cell_text = cell.text# .strip()  # Strip any leading/trailing whitespace
        print(cell_text)
        options = cell_text.split("\n")
        print(options[0])
        options = cell_text.split("\n")
    for option in options:
        print(option)
        print(f"Option: {option.strip()}, Unicode: {[ord(c) for c in option.strip()]}")


    if checked_symbol in cell_text:  # If the checkbox is checked
        options = cell_text.split("\n")
        for option in options:
            if "☐" in option:
                print(option)
        for opt in options:
            print(opt)
            if checked_symbol in opt:
                checked_boxes.append(opt)#((row_idx, col_idx))  # Append the index of the checked box
            else:
                checked_boxes.append("Manual")    
        if cell_text and cell_text not in seen_cells:  # Only add non-empty unique text
            row_text.append(cell_text)
            seen_cells.add(cell_text)  # Mark this cell text as processed
                
        if row_text:  # Only append the row if there is non-empty content
            all_cells_text.append(row_text)
        
    return all_cells_text, checked_boxes

# Example usage
# x, checked = read_worddata(3)  # Get all data from the 4th table (index starts at 0)
# row_three = x[2]
# row_four = x[3]
# row_five = x[4]
# row_six = x[5]
# Print the content of the first row
# print(row_six)  # This will print the first row of the table
# print(checked)

table = doc.tables[3]  # Access the table by its index (starts at 0)
checked_symbol = "☒ - No"
checkbox_associations = []
row = table.rows[5]
cell = row.cells[1]
cell_text = cell.text
options = cell_text.split("\n")

print(options[0])
print(options[1])

for tabs in doc.tables:
    for trow in tabs.rows:
        row_data =  [cell.text for cell in trow.cells]
        print(row_data)


tables_data = []

for table in doc.tables:
    table_data = []
    for row in table.rows:
        table_data.append([cell.text for cell in row.cells])
    tables_data.append(table_data)

# Print or process the collected data
for i, table in enumerate(tables_data, start=1):
    print(f"Table {i}:")
    for row in table:
        print(row)

def read_worddata(tableNo):
    table = doc.tables[tableNo]  # Access the 4th table (index starts at 0)
    row = table.rows[2]    # Access the 3rd row (index starts at 0)
    # Avoid reprocessing merged cells by checking text content
    CSDRef = row.cells[0]
    CSDRefNo = row.cells[1]
    if CSDRef.text and CSDRefNo.text:  # Only proceed if there's actual content in the cell
        CSDRef_Text = CSDRef.text
        CSDRefNo_Text = CSDRefNo.text
    return CSDRef_Text, CSDRefNo_Text
x = read_worddata(3)
print(f'{x[0]} - {x[1]}')


if cell_text == checked_symbol:
    print(f'this is checked box: {cell_text}')
else:
    print(f'this is full string: {cell_text}')
    cell_text = cell.text.strip()  # Get the text content and remove extra whitespace
    # Check for checkboxes and associate the correct string
    # checkbox_associations.append(( checked_string))  # Append "No" for checked boxes

print(checkbox_associations)        

for row in x:
    print(row[0])  # Print each row's content

table = doc.tables[3]  # Get the 4th table (index starts at 0)
row = table.rows[2]    # Get the 3rd row (index starts at 0)

# Track printed cells to avoid printing merged cells multiple times
printed_cells = []

for i, cell in enumerate(row.cells):
    # If the cell is already merged with the previous cell, skip it
    if cell not in printed_cells:
        print(cell.text)
        printed_cells.append(cell)


for cell in row.cells:
        print(cell.text) 
cell = row.cells[0]
print(cell.text)

for cell in row.cells:
        print(cell.text)

for row in table.rows:
    print(row[0])
    for cell in row.cells:
        print(cell)
        out1 = cell.text

print(out1)    
print([cell.text for cell in row.cells])

text = "\n".join([para.text for para in doc.paragraphs])
print(text)

exit()

# import docx
# print(docx.__version__)
# import site
# print(site.getsitepackages())  # System-wide site-packages
# print(site.getusersitepackages())  # User-specific site-packages

