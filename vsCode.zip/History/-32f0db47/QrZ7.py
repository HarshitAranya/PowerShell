class Output:
  def __init__(self, itemPrice, userInput):
    self.calcu = (1000/itemPrice) * userInput
  

resultOut = Output(52, 26)
print(resultOut.calcu)


class Output:
  def __init__(self, itemPrice, userInput):
    self.calcu = (1000/itemPrice) * userInput
  def __str__(self):
    return f"{self.calcu} LTR"

resultOut = Output(52, 26)
print(resultOut)