class InputAmountError(ValueError):
    pass

class Quantity:
    def __init__(self, itemPrice: int, userInput: int):
        self.itemPrice = itemPrice
        self.userInput = userInput
        if self.userInput == 0:
            raise InputAmountError(
                f"Enter Valid Amount. Entered amount is: {userInput}"
            )
        qty = (1000/itemPrice) * userInput
        return(
            qty
        )


output = Quantity(52, 26)

try:
    output
except InputAmountError as e:
    print(e)

# new
calcu = lambda a, b: a * b
print(calcu(5, 6))