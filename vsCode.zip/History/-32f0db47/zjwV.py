class InputAmountError(ValueError):
    pass

class Quantity:
    def __init__(self, itemPrice: int, userInput: int):
        self.itemPrice = itemPrice
        self.userInput = userInput
        if self.userInput == 0:
            raise InputAmountError(
                f"Enter Valid Amount. Entered amount is: {userInput}"
            )
        qty = (1000/itemPrice) * userInput
        return(
            qty
        )


output = Quantity(52, 26)

try:
    output
except InputAmountError as e:
    print(e)

# new
calcu = lambda a, b: a * b
print(calcu(5, 6))

# new

def calculate(*values, operator):
    return operator(*values)

result = calculate(20, 4, operator=divide)
print(result)

#New
def search(sequence, expected, finder):
    for elem in sequence:
        if finder(elem) == expected:
            return elem
    raise RuntimeError(f"Could not find {expected}.")


friends = [
    {"name": "harshit", "age": 30},
    {"name": "jyoti", "age": 20},
    {"name": "rina", "age": 23}
]

def get_friend_name(friend):
    return friend["name"]

print(search(friends, "rina", get_friend_name))

# new
# Decorater to replace or secure funtion




