itemsMaster = ["Milk", 62, "LTR"]
userInput = int(input("Enter Amount: "))

class Qusntity:
    def calculation(itemPrice, userInput):
        qty = (1000/itemPrice) * userInput
        return qty
