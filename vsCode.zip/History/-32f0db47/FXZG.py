class Output:
  def __init__(self, itemPrice, userInput):
    self.calcu = (1000/itemPrice) * userInput
  

resultOut = Output(52, 26)
print(resultOut.calcu)



class Output:
  def __init__(self, itemPrice, userInput):
    self.calcu = (1000/itemPrice) * userInput
  def __str__(self):
    return f"{self.calcu} LTR"

# resultOut = Output(52, 26)
# print(resultOut)
print(Output(52, 26))


class Output:
  def __init__(self, itemPrice, userInput):
    self.unit = (1000/itemPrice) * userInput
  
  @classmethod
  def bagPrice(cls, itemPrice, userInput):
  	return userInput * itemPrice

resultOut = Output.bagPrice(40, 2)
# int(resultOut.unit)

print(resultOut)