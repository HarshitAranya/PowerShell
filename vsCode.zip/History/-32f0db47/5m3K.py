# class Output:
#   def __init__(self, itemPrice, userInput):
#     self.calcu = (1000/itemPrice) * userInput
  

# resultOut = Output(52, 26)
# print(resultOut.calcu)



# class Output:
#   def __init__(self, itemPrice, userInput):
#     self.calcu = (1000/itemPrice) * userInput
#   def __str__(self):
#     return f"{self.calcu} LTR"

# # resultOut = Output(52, 26)
# # print(resultOut)
# print(Output(52, 26))


# class Output:
#   def __init__(self, itemPrice, userInput):
#     self.unit = (1000/itemPrice) * userInput
  
#   @classmethod
#   def bagPrice(cls, itemPrice, userInput):
#   	return userInput * itemPrice

# resultOut = Output.bagPrice(40, 2)
# # int(resultOut.unit)

# print(resultOut)

# Error in python

# def qty(itemPrice, userInput):
#   if userInput == 0:
#     raise ZeroDivisionError("Error 0")
#     # print("Error")
#   return (1000/itemPrice) * userInput


# try:
#   output = qty(52, 26)
# except ZeroDivisionError:
#   print("Error")

# print(f"This is the qty :{output} of milk")


# def qty(itemPrice, userInput):
#   if userInput == 0:
#     raise ZeroDivisionError("Error 0")
#     # raise RuntimeError ("Runtime")
#     # raise TypeError ("Type Error")
#     # raise ValueError ("Value erorr")

#     # print("Error")
#   return (1000/itemPrice) * userInput


# try:
#   output = qty(52, 26)
#   # print(f"This is the qty :{output} of milk")
# except ZeroDivisionError as e:
#   print("Error")
#   # print(e)
# else:
#   print(f"This is the qty :{output} of milk")
# finally:
#   print("Thanks you")
  

