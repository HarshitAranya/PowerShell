from tkinter import X

#Master Data
# allItems = [
#     {"item1": "Dudh_Cow", "price1": 64, "sunit1": "ML", "lunit": "LTR"},
#     {"item2": "Dahi", "price2": 90, "sunit1": "Gram", "lunit": "KG"},
#     {"item3": "Aahar", "price3": 1012, "sunit1": "Bag", "lunit": "Bag"}
# ]

# for itemName, price, sunit, lunit in allItems.items():
#     print(f"{itemName}: {price} | {sunit} | {lunit}" )

allItems = [
    ("ItemCode", "ItemName", "Price", "SmallUnit", "LargUnit")
    (1, "Dudh_Cow", 64, "ML", "LTR"),
    (2, "Dahi", 90, "Gram", "KG"),
    (3, "Aahar", 1012, "Bag", "Bag")
]

for itemCode, itemName, price, sunit, lunit in allItems.items():
    print(f"{itemCode} {itemName}: {price} | {sunit} | {lunit}" )
    print(allItems[1][0])

oneItem = (1, "Dudh_Cow", 64, "ML", "LTR")
ItemCode, ItemName, Price, SmallUnit, LargUnit = oneItem
print(ItemName, Price)

# print(allItems[0]["item1"])

# for item in allItems:
#     print(f"{item}: {allItems[item]}")

# units = 'read from excel'
# itemsPrice = 'read from excel'

selection = int(input("Enter Item Code: "))

if selection not in [1,2,3,4,5,6,7,8]:
    print("Enter Valid Code")
    exit

for unit in units:
    displayUnit = unit[selection-1]

if selection == 8:
    userInput = int(input("Enter Quantity of Bag: "))
    bagPrice = userInput * itemsPrice[selection]
    print(f"The amount of {userInput} Bag is {bagPrice}/-")
else:
    userInput = int(input("Enter Amount: "))
    itemPrice = itemsPrice[selection]
    quantity = itemPrice / userInput
    print(f"The quantity of item is {quantity:.2f} {unit}")



# x = "hello {} {}, how are you "
# display = x.format("harshit", "aranya")
# print(display)

# userInput = input("Enter Amount: ")
# print(userInput)

# listOfItems = ["Milk", "Buttor Milk", "Paneer"]
# tupleOfItems = ("Milk", "Buttor Milk", "Paneer")
# if "Milk" in listOfItems:
#     print(listOfItems[0])
# elif "Milk" not in listOfItems:
#     print("Not Found")

# print(listOfItems[1])
# print(tupleOfItems[2])


# selection = input("Enter Item Code: ").int()

 


# listOfItems = [1,2,3,4,5,6,7,8]
# if selection not in listOfItems:
#     print("Enter Valid Code")



# while selection in [1,2,3,4,5,6,7,8]:
    # print("ok")
    # break




# if selection != int():
#     print("Enter Valid Code")
#     selection = input("Enter Item Code: ")

# elif selection > 8 :
#     print("Enter Valid Code")
#     selection = input("Enter Item Code: ")

# elif selection < 1 :
#     print("Enter Valid Code")
#     selection = input("Enter Item Code: ")
# else:
#     print("Code is valid")




