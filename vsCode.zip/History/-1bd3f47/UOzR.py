from tkinter import X


x = "hello {} {}, how are you "
display = x.format("harshit", "aranya")
print(display)

# userInput = input("Enter Amount: ")
# print(userInput)

# listOfItems = ["Milk", "Buttor Milk", "Paneer"]
# tupleOfItems = ("Milk", "Buttor Milk", "Paneer")
# print(listOfItems[1])
# print(tupleOfItems[2])



unit = 'read from excel'
itemsPrice = 'read from excel'
selection = input("Enter Item Code: ")
itemPrice = itemsPrice[selection]
userInput = int(input("Enter Amount: "))
quantity = itemPrice / userInput
# print(userInput)
print(f"The quantity of item is {quantity:.2f} {unit}")
