from tkinter import X


x = "hello {} {}, how are you "
display = x.format("harshit", "aranya")
print(display)

# userInput = input("Enter Amount: ")
# print(userInput)

# listOfItems = ["Milk", "Buttor Milk", "Paneer"]
# tupleOfItems = ("Milk", "Buttor Milk", "Paneer")
# print(listOfItems[1])
# print(tupleOfItems[2])

unit = 'read from excel'
itemsPrice = 'read from excel'
selection = input("Enter Item Code: ").int()
if selection != int():
    print("Enter Valid Code")
    # selection = input("Enter Item Code: ")

elif selection > 8 :
    print("Enter Valid Code")
    # selection = input("Enter Item Code: ")

elif selection < 1 :
    print("Enter Valid Code")
    # selection = input("Enter Item Code: ")
else:
    print("Code is valid")

if selection == 8:
    userInput = int(input("Enter Quantity of Bag: "))
    bagPrice = userInput * itemsPrice[selection]
    print(f"The amount of {userInput} Bag is {bagPrice}/-")

itemPrice = itemsPrice[selection]
userInput = int(input("Enter Amount: "))
quantity = itemPrice / userInput
# print(userInput)
print(f"The quantity of item is {quantity:.2f} {unit}")
