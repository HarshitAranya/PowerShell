from tkinter import X


x = "hello {} {}, how are you "
display = x.format("harshit", "aranya")
print(display)

userInput = input("Enter Amount: ")
print(userInput)

