from tkinter import X

#Master Data
units = 'read from excel'
itemsPrice = 'read from excel'

selection = int(input("Enter Item Code: "))

if selection not in [1,2,3,4,5,6,7,8]:
    print("Enter Valid Code")
    exit

for unit in units:
    displayUnit = unit[selection-1]

if selection == 8:
    userInput = int(input("Enter Quantity of Bag: "))
    bagPrice = userInput * itemsPrice[selection]
    print(f"The amount of {userInput} Bag is {bagPrice}/-")
else:
    userInput = int(input("Enter Amount: "))
    itemPrice = itemsPrice[selection]
    quantity = itemPrice / userInput
    print(f"The quantity of item is {quantity:.2f} {unit}")



# x = "hello {} {}, how are you "
# display = x.format("harshit", "aranya")
# print(display)

# userInput = input("Enter Amount: ")
# print(userInput)

# listOfItems = ["Milk", "Buttor Milk", "Paneer"]
# tupleOfItems = ("Milk", "Buttor Milk", "Paneer")
# if "Milk" in listOfItems:
#     print(listOfItems[0])
# elif "Milk" not in listOfItems:
#     print("Not Found")

# print(listOfItems[1])
# print(tupleOfItems[2])


# selection = input("Enter Item Code: ").int()

 


# listOfItems = [1,2,3,4,5,6,7,8]
# if selection not in listOfItems:
#     print("Enter Valid Code")



# while selection in [1,2,3,4,5,6,7,8]:
    # print("ok")
    # break




# if selection != int():
#     print("Enter Valid Code")
#     selection = input("Enter Item Code: ")

# elif selection > 8 :
#     print("Enter Valid Code")
#     selection = input("Enter Item Code: ")

# elif selection < 1 :
#     print("Enter Valid Code")
#     selection = input("Enter Item Code: ")
# else:
#     print("Code is valid")




