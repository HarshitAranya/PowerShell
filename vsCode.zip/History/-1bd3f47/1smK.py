from tkinter import X


x = "hello {} {}, how are you "
display = x.format("harshit", "aranya")
print(display)
